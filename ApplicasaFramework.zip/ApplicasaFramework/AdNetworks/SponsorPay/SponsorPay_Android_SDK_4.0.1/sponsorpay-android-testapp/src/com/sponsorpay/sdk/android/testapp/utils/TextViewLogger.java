package com.sponsorpay.sdk.android.testapp.utils;

import android.graphics.Color;
import android.text.Layout;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.format.Time;
import android.text.method.ScrollingMovementMethod;
import android.text.style.ForegroundColorSpan;
import android.widget.TextView;

import com.sponsorpay.sdk.android.utils.SPLoggerListener;
import com.sponsorpay.sdk.android.utils.SponsorPayLogger.Level;

public class TextViewLogger implements SPLoggerListener{
	
	public static TextViewLogger INSTANCE = new TextViewLogger();

	private TextView mTextView;
	
	private Time mTime = new Time();
	
		private TextViewLogger() {
	}
	
	public void setTextView(TextView textView) {
		mTextView = textView;
		mTextView.setMovementMethod(new ScrollingMovementMethod());
	}
	
	public TextView getTextView() {
		return mTextView;
	}
	
	@Override
	public void log(Level level, String tag, String message, Exception exception) {
		
		mTime.setToNow();

		ForegroundColorSpan colorSpan = getColorSpan(level);
		
		String text = mTime.format2445()
				+ " ["
				+ tag
				+ "]\n"
				+ message
				+ (exception != null ? " - Exception: "
						+ exception.getLocalizedMessage() : "") + "\n\n";

		final Spannable spannedText = new SpannableString(text);

		spannedText.setSpan(colorSpan, 0, text.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		mTextView.post(new Runnable() {
			@Override
			public void run() {
				mTextView.append(spannedText);

				Layout layout = mTextView.getLayout();
				if (layout != null) {
					final int scrollAmount = layout.getLineTop(
							mTextView.getLineCount())
							- mTextView.getHeight();
					// if there is no need to scroll, scrollAmount will be <=0
					if (scrollAmount > 0) {
						mTextView.scrollTo(0, scrollAmount);
					}
				}
			}
		});
	}
	
	private ForegroundColorSpan getColorSpan(Level level) {
		ForegroundColorSpan colorSpan;
		
		switch (level) {
		case DEBUG:
			colorSpan = new ForegroundColorSpan(Color.BLUE);
			break;
		case INFO:
			colorSpan = new ForegroundColorSpan(Color.GREEN);
			break;
		case WARNING:
			colorSpan = new ForegroundColorSpan(Color.rgb(0xFF,0xA5,0x00));
			break;
		case ERROR:
			colorSpan = new ForegroundColorSpan(Color.RED);
			break;
		case VERBOSE:
		default:
			colorSpan = new ForegroundColorSpan(Color.BLACK);
			break;
		}
		return colorSpan;
	}
	
}
