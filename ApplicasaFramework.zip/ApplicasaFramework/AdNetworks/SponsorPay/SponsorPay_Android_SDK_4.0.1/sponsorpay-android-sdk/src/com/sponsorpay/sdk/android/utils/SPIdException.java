/**
 * SponsorPay Android SDK
 *
 * Copyright 2011 - 2013 SponsorPay. All rights reserved.
 */

package com.sponsorpay.sdk.android.utils;

public class SPIdException extends Exception {
	
	private static final long serialVersionUID = 4315205868647624054L;

	public SPIdException(String message) {
		super(message);
	}		
}