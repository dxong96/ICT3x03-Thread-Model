/**
 * SponsorPay Android SDK
 *
 * Copyright 2011 - 2013 SponsorPay. All rights reserved.
 */

package com.sponsorpay.sdk.android.utils;

import java.util.HashMap;
import java.util.Map;

public class SponsorPayBaseUrlProvider {

	private static SponsorPayBaseUrlProvider INSTANCE = new SponsorPayBaseUrlProvider();

	private SPUrlProvider mUrlProviderOverride;
	
	@SuppressWarnings("serial")
	private Map<String, String> urls = new HashMap<String, String>() {{
		put("actions", "https://service.sponsorpay.com/actions/v2");
		put("installs", "https://service.sponsorpay.com/installs/v2");
		put("vcs", "https://api.sponsorpay.com/vcs/v1/new_credit.json");
		put("mbe", "https://iframe.sponsorpay.com/mbe");
		put("unlock_items", "https://api.sponsorpay.com/vcs/v1/items.json");
		put("interstitial", "https://iframe.sponsorpay.com/mobile");
		put("banner", "https://iframe.sponsorpay.com/mobile");
		put("ofw", "https://iframe.sponsorpay.com/mobile");
		put("unlock", "https://iframe.sponsorpay.com/unlock");
	}};
	
	private SponsorPayBaseUrlProvider() {
	}

	private String getUrl(String product) {
		String baseUrl = null;
		if (mUrlProviderOverride != null) {
			baseUrl = mUrlProviderOverride.getBaseUrl(product);
		} 
		if (StringUtils.nullOrEmpty(baseUrl)) {
			baseUrl = urls.get(product);
		}
		return baseUrl;
	}
	
	private void setOverride(SPUrlProvider provider) {
		mUrlProviderOverride = provider;
	}
	
	public static void setProviderOverride(SPUrlProvider provider) {
		SponsorPayBaseUrlProvider.INSTANCE.setOverride(provider);
	}

	public static String getBaseUrl(String product) {
		return SponsorPayBaseUrlProvider.INSTANCE.getUrl(product);
	}
}
